Vasco Lenzi - MathWorks 2017
----------------------------

To have the ball on wheel demo working:

1) search for the Contact Forces Library on MATLAB central or the Add-on app in the main menu;
https://ch.mathworks.com/matlabcentral/fileexchange/47417-simscape-multibody-contact-forces-library

2) run BoW_Parameters.m

3) Open an appropriate simulink file and click run.

Have fun!

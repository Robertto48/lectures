
%------------%
% Parameters %
%------------%

% known Parameters:

m = 0.2311;          % Ball mass [kg]
theta_ball = 4.968e-004;  % Ball inertia [kg*m^2]
r = 0.105/2;         % Ball radius [m]
R = 0.2;             % Wheel radius [m]
w_whl_notch = 0.08;  % Wheel height (internal distance between the discs) [m]
cf_r_cyl = sqrt(r^2-w_whl_notch^2/4);  %Radius of sitting cylinder [m]
cf_w_cyl = r;        % Height of sitting cylinder [m]

r_whl_contact = 0.2; % m
r_whl_outer = 0.2;   % m
r_whl_inner = 0.025;   % m
r_whl_inner2 = 0.0255;  % m
w_whl = 0.09;          % m



Extr_Data_Wheel = flipud([...
r_whl_outer     w_whl/2       ;
     r_whl_outer w_whl_notch/2 ;
     r_whl_inner2 w_whl_notch/2 ;
     r_whl_inner2 -w_whl_notch/2 ;
    r_whl_outer -w_whl_notch/2 ;
    r_whl_outer -w_whl/2 ;
    r_whl_inner -w_whl/2 ;
    r_whl_inner w_whl/2 ]);                                            
r_snake = sqrt(r^2-w_whl_notch^2/4);                    % Radius des gesetzten Balls [m]
g = 9.81;                                               % Erdbeschleunigung [m/s^2]
R_snake = R + r_snake;                                  % Abstand Achse-Ballschwerpunkt [m]
kappa = 0.147;                                          % Motorkonstante [Nm/A]
max_current = 5.850;                                    % Maximal zul�ssiger Strom Maxonmotor EC60 [A]
Speed_max_rpm = 300;                                    % Maximal zul�ssige Drehzahl [rpm]
Speed_max = Speed_max_rpm * 2 * pi / 60;                % Maximal zul�ssige Drehzahl [rad/s] 
T_max = max_current * kappa;                            % Maximales Moment auf Welle [Nm]
Chi_max = pi/4;                                         % Normierungswert f�r Chi
Psi_dot_norm = 4*pi;                                    % Normierungswert f�r Psi_dot

% Parameter (identifiert)
Theta_wheel = 0.021;                                          % Tr�gheitsmoment Achse und Rad (total) [kg*m^2]

% Definierte Variablen

Gamma = Theta_wheel*theta_ball + m*(R^2*theta_ball+r_snake^2*Theta_wheel);
st = 1e-3;                                              % Sample Time [s]


% Betriebspunkt
Chi_Btr = 0;                                            % Linearisierter Betriebspunkt
Psi_dot_Btr = 0;

% Initial Conditions
Chi_0=0;                                                % Anfangswerte f�r Modelle
Chi_dot_0=0;
Psi_dot_0=0;


%From Vasco:

%Old demo values:
k1 =-0.5;
k2=-0.01;
k3=0;
k4=0.00001;
A = [   0   0.682216263501428                   0;
        0                   0   1.273239544735163;
        0  16.280222857179943                   0];
 
B = [   2.533515350151650;
                        0;
       17.693902046841078];

C = [1     0     0;
     0     1     0];
 
C_i = [0     1     0];
 
 D = [0;
      0];
  
D_i=0;


  
  
sys_ss = ss(A,B,C,D);           % Zustandsraummodell
sys_tf = minreal(tf(sys_ss));   % Matrix mit ?bertragungsfunktionen
sys_ss_i1 = ss(A,B,C_i,D_i);           % Zustandsraummodell
sys_tf_i = minreal(tf(sys_ss_i1));
sys_tf_i.Denominator{1}(2)=0;

[A2,B2,C2,D2]=tf2ss(sys_tf_i.Numerator{1},sys_tf_i.Denominator{1});
sys_ss_i2=ss(A2,B2,C2,D2);
% meas= timeseries(zeros(3001,1),[0:0.01:30]');
% meas.Name='Ball Chi [rad]';